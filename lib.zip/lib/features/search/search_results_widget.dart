import 'package:degloor_one/backend/supabase/supabase.dart';
import 'package:degloor_one/backend/location_service.dart';
import 'package:degloor_one/components/business_card800502e0/business_card800502e0_widget.dart';
import 'package:degloor_one/components/button/button_widget.dart';
import 'package:degloor_one/components/filter_chip/filter_chip_widget.dart';
import 'package:degloor_one/components/text_field/text_field_widget.dart';
import 'package:degloor_one/flutter_flow/flutter_flow_icon_button.dart';
import 'package:degloor_one/flutter_flow/flutter_flow_theme.dart';
import 'package:degloor_one/flutter_flow/flutter_flow_util.dart';
import 'package:degloor_one/app_state.dart';
import 'package:degloor_one/components/empty_state_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'search_results_model.dart';
export 'search_results_model.dart';

class SearchResultsWidget extends StatefulWidget {
  const SearchResultsWidget({
    super.key,
    this.searchTerm,
    this.categoryId,
    this.openNow,
  });

  final String? searchTerm;
  final String? categoryId;
  final bool? openNow;

  static String routeName = 'SearchResults';
  static String routePath = '/searchResults';

  @override
  State<SearchResultsWidget> createState() => _SearchResultsWidgetState();
}

class _SearchResultsWidgetState extends State<SearchResultsWidget> {
  late SearchResultsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  Future<List<BusinessesRow>>? _searchResultsFuture;
  Future<Map<String, bool>>? _openStatusesFuture;
  String? _currentSearchTerm;
  String? _currentCategoryId;
  Map<String, String> _categoryIdToName = {};

  bool _onlyVerified = false;
  bool _onlyOpen = false;
  bool _minRating4 = false;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SearchResultsModel());
    _currentSearchTerm = widget.searchTerm;
    _currentCategoryId = widget.categoryId;
    _onlyOpen = widget.openNow ?? false;
    _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);

    BusinessCategoriesTable().queryRows(queryFn: (q) => q).then((rows) {
      if (mounted) {
        setState(() {
          for (var row in rows) {
            _categoryIdToName[row.id] = row.name;
          }
        });
      }
    });
  }

  Future<void> _performSearch(String? term, {String? categoryId}) async {
    setState(() {
      _currentSearchTerm = term;
      _currentCategoryId = categoryId;

      final userLoc = FFAppState.instance.userLocation;
      final radius = FFAppState.instance.discoveryRadius;

      if (userLoc != null) {
        _searchResultsFuture = BusinessesTable().searchInRadius(
          latitude: userLoc.latitude,
          longitude: userLoc.longitude,
          radiusKm: radius,
          searchTerm: term,
          categoryId: categoryId,
          verifiedOnly: _onlyVerified,
          openNow: _onlyOpen,
          minRating: _minRating4 ? 4.0 : 0.0,
        );
      } else {
        _searchResultsFuture = Future.value([]);
      }

      _openStatusesFuture = _searchResultsFuture?.then((rows) =>
          getMultipleBusinessesOpenStatus(rows.map((r) => r.id).toList()));
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.rectangle,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(20.0, 12.0, 20.0, 12.0),
                    child: Container(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              FlutterFlowIconButton(
                                borderRadius: 8.0,
                                buttonSize: 40.0,
                                fillColor: Colors.transparent,
                                icon: Icon(
                                  Icons.arrow_back_rounded,
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  size: 24.0,
                                ),
                                onPressed: () async {
                                  context.safePop();
                                },
                              ),
                              Expanded(
                                flex: 1,
                                child: wrapWithModel(
                                  model: _model.textFieldModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: TextFieldWidget(
                                    label: '',
                                    labelPresent: false,
                                    helper: '',
                                    helperPresent: false,
                                    leadingIcon: Icon(
                                      Icons.search_rounded,
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                      size: 24.0,
                                    ),
                                    leadingIconPresent: true,
                                    trailingIconPresent: false,
                                    hint: 'Search hardware, food...',
                                    value: _currentSearchTerm,
                                    onSubmit: (val) {
                                      _performSearch(val);
                                    },
                                    variant: 'filled',
                                    error: false,
                                  ),
                                ),
                              ),
                              FlutterFlowIconButton(
                                borderColor:
                                    FlutterFlowTheme.of(context).alternate,
                                borderRadius: 8.0,
                                borderWidth: 1.0,
                                buttonSize: 40.0,
                                fillColor: Colors.transparent,
                                icon: Icon(
                                  Icons.tune_rounded,
                                  color: FlutterFlowTheme.of(context).primary,
                                  size: 24.0,
                                ),
                                onPressed: () {
                                  print('IconButton pressed ...');
                                },
                              ),
                            ].divide(const SizedBox(width: 16.0)),
                          ),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                wrapWithModel(
                                  model: _model.filterChipModel1,
                                  updateCallback: () => safeSetState(() {}),
                                  child: FilterChipWidget(
                                    hasIcon: true,
                                    label:
                                        '${FFAppState.instance.discoveryRadius.toInt()} km',
                                    selected: true,
                                    onTap: () async {
                                      final result = await showModalBottomSheet<double>(
                                        context: context,
                                        builder: (context) => Container(
                                          padding: const EdgeInsets.all(24),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text('Select Search Radius',
                                                  style: FlutterFlowTheme.of(context).titleMedium),
                                              const SizedBox(height: 16),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                children: [2, 5, 10, 20, 50].map((r) => InkWell(
                                                  onTap: () => Navigator.pop(context, r.toDouble()),
                                                  child: Container(
                                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                                    decoration: BoxDecoration(
                                                      color: FFAppState.instance.discoveryRadius == r ? FlutterFlowTheme.of(context).primary : Colors.transparent,
                                                      borderRadius: BorderRadius.circular(20),
                                                      border: Border.all(color: FlutterFlowTheme.of(context).alternate),
                                                    ),
                                                    child: Text('${r}km',
                                                      style: TextStyle(color: FFAppState.instance.discoveryRadius == r ? Colors.white : FlutterFlowTheme.of(context).primaryText),
                                                    ),
                                                  ),
                                                )).toList(),
                                              ),
                                              const SizedBox(height: 16),
                                            ],
                                          ),
                                        ),
                                      );
                                      if (result != null) {
                                        setState(() {
                                          FFAppState.instance.discoveryRadius = result;
                                        });
                                        _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);
                                      }
                                    },
                                  ),
                                ),
                                wrapWithModel(
                                  model: _model.filterChipModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: FilterChipWidget(
                                    hasIcon: false,
                                    label: 'Verified',
                                    selected: _onlyVerified,
                                    onTap: () {
                                      setState(() {
                                        _onlyVerified = !_onlyVerified;
                                        _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);
                                      });
                                    },
                                  ),
                                ),
                                wrapWithModel(
                                  model: _model.filterChipModel3,
                                  updateCallback: () => safeSetState(() {}),
                                  child: FilterChipWidget(
                                    hasIcon: false,
                                    label: 'Open Now',
                                    selected: _onlyOpen,
                                    onTap: () {
                                      setState(() {
                                        _onlyOpen = !_onlyOpen;
                                        _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);
                                      });
                                    },
                                  ),
                                ),
                                wrapWithModel(
                                  model: _model.filterChipModel4,
                                  updateCallback: () => safeSetState(() {}),
                                  child: FilterChipWidget(
                                    hasIcon: false,
                                    label: 'Rating 4.0+',
                                    selected: _minRating4,
                                    onTap: () {
                                      setState(() {
                                        _minRating4 = !_minRating4;
                                        _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);
                                      });
                                    },
                                  ),
                                ),
                              ].divide(const SizedBox(width: 0.0)),
                            ),
                          ),
                        ].divide(const SizedBox(height: 16.0)),
                      ),
                    ),
                  ),
                  Container(
                    height: 1.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).alternate,
                      shape: BoxShape.rectangle,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                child: SingleChildScrollView(
                  primary: false,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Container(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              FutureBuilder<List<BusinessesRow>>(
                                future: _searchResultsFuture ?? Future.value([]),
                                builder: (context, snapshot) {
                                  if (!snapshot.hasData) {
                                    return Center(
                                      child: Padding(
                                        padding: const EdgeInsets.all(20.0),
                                        child: CircularProgressIndicator(
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            FlutterFlowTheme.of(context)
                                                .primary,
                                          ),
                                        ),
                                      ),
                                    );
                                  }
                                  final allBusinesses = snapshot.data!;

                                  return FutureBuilder<Map<String, bool>>(
                                    future: _openStatusesFuture,
                                    builder: (context, statusSnapshot) {
                                      final statuses =
                                          statusSnapshot.data ?? {};

                                      final businesses = allBusinesses;

                                      final showNoResults = businesses.isEmpty;

                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.stretch,
                                        children: [
                                          if (businesses.isNotEmpty) ...[
                                            Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  '${businesses.length} Businesses found',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelLarge
                                                      .override(
                                                        fontFamily:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelLargeFamily,
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        useGoogleFonts:
                                                            GoogleFonts.asMap()
                                                                .containsKey(
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .labelLargeFamily),
                                                      ),
                                                ),
                                              ],
                                            ),
                                            ...businesses.map((business) {
                                              final isOpen =
                                                  statuses[business.id] ??
                                                      false;
                                              return InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  context.pushNamed(
                                                    'BusinessProfile',
                                                    queryParameters: {
                                                      'businessId':
                                                          serializeParam(
                                                        business.id,
                                                        ParamType.String,
                                                      ),
                                                    }.withoutNulls,
                                                  );
                                                },
                                                child:
                                                    BusinessCard800502e0Widget(
                                                  key: Key(
                                                      'search_${business.id}'),
                                                  address:
                                                      business.addressText ??
                                                          'Degloor',
                                                  category: _categoryIdToName[
                                                          business
                                                              .categoryId] ??
                                                      'Local Business',
                                                  distance: business.distanceKm != null
                                                      ? business.distanceKm!.toStringAsFixed(1)
                                                      : getDistance(
                                                          business.latitude,
                                                          business.longitude)
                                                      .replaceAll(' km', ''),
                                                  imgDesc: business.imageUrl ??
                                                      'https://images.unsplash.com/photo-1534723452862-4c874018d66d?auto=format&fit=crop&w=400&h=300&q=80',
                                                  isOpen: isOpen,
                                                  isVerified:
                                                      business.isVerified ??
                                                          false,
                                                  name: business.name,
                                                  rating: (business.rating ??
                                                          0.0)
                                                      .toString(),
                                                  phoneNumber: business.phoneNumber,
                                                  whatsappNumber: business.whatsappNumber,
                                                  latitude: business.latitude,
                                                  longitude: business.longitude,
                                                ),
                                              );
                                            }),
                                          ],
                                          if (showNoResults)
                                            EmptyStateView(
                                              icon: FFAppState.instance.userLocation == null
                                                  ? Icons.location_off_rounded
                                                  : Icons.search_off_rounded,
                                              title: FFAppState.instance.userLocation == null
                                                  ? 'Location Required'
                                                  : 'No results found',
                                              description: FFAppState.instance.userLocation == null
                                                  ? 'We need your location to show nearby businesses'
                                                  : 'Try adjusting your filters or searching for something else',
                                              buttonText: FFAppState.instance.userLocation == null
                                                  ? 'Enable Location'
                                                  : null,
                                              onTap: FFAppState.instance.userLocation == null
                                                  ? () => LocationService.updateCurrentLocation(context)
                                                  : null,
                                            ),
                                        ].divide(const SizedBox(height: 16.0)),
                                      );
                                    },
                                  );
                                },
                              ),
                              Container(
                                child: Padding(
                                  padding: const EdgeInsets.all(32.0),
                                  child: Container(
                                    child: Container(
                                      alignment: const AlignmentDirectional(0.0, 0.0),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.search_off_rounded,
                                            color: FlutterFlowTheme.of(context)
                                                .onBackground,
                                            size: 32.0,
                                          ),
                                          Text(
                                            'Looking for more?',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: GoogleFonts.inter().fontFamily,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryText,
                                                  letterSpacing: 0.0,
                                                  lineHeight: 1.5,
                                                ),
                                          ),
                                          wrapWithModel(
                                            model: _model.buttonModel,
                                            updateCallback: () =>
                                                safeSetState(() {}),
                                            child: ButtonWidget(
                                              iconPresent: false,
                                              iconEndPresent: false,
                                              content:
                                                  'Increase Radius to ${FFAppState.instance.discoveryRadius.toInt() + 5} km',
                                              variant: 'outline',
                                              size: 'small',
                                              fullWidth: false,
                                              loading: false,
                                              disabled: false,
                                              onTap: () async {
                                                setState(() {
                                                  FFAppState.instance.discoveryRadius += 5;
                                                });
                                                _performSearch(_currentSearchTerm, categoryId: _currentCategoryId);
                                              },
                                            ),
                                          ),
                                        ].divide(const SizedBox(height: 8.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ].divide(const SizedBox(height: 16.0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
