import 'package:flutter/material.dart';
import 'package:degloor_one/auth/supabase_auth/auth_util.dart';
import 'package:degloor_one/flutter_flow/flutter_flow_util.dart';
import 'package:degloor_one/flutter_flow/flutter_flow_theme.dart';

class InitialRedirectWidget extends StatefulWidget {
  const InitialRedirectWidget({super.key});

  static String routeName = 'InitialRedirect';
  static String routePath = '/initialRedirect';

  @override
  State<InitialRedirectWidget> createState() => _InitialRedirectWidgetState();
}

class _InitialRedirectWidgetState extends State<InitialRedirectWidget> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _handleRedirect());
  }

  Future<void> _handleRedirect() async {
    if (!loggedIn) {
      context.goNamed('Authentication');
      return;
    }

    String? role = currentUser?.role;

    // Fallback: If role is missing but logged in, try fetching it.
    if (role == null) {
      role = await getCurrentUserRole();
    }

    if (role == 'business_owner') {
      context.goNamed('BusinessDashboard');
    } else if (role == 'admin') {
      context.goNamed('AdminControlPanel');
    } else {
      context.goNamed('CustomerHome');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: const Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
