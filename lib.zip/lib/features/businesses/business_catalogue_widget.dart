// Removed for Phase 1
import 'package:flutter/material.dart';

class BusinessCatalogueWidget extends StatelessWidget {
  const BusinessCatalogueWidget({super.key, required this.businessId});
  final String businessId;
  @override
  Widget build(BuildContext context) => const Scaffold();
}
