import 'package:degloor_one/flutter_flow/flutter_flow_util.dart';
import 'package:degloor_one/features/businesses/business_catalogue_widget.dart' show BusinessCatalogueWidget;
import 'package:flutter/material.dart';

class BusinessCatalogueModel extends FlutterFlowModel<BusinessCatalogueWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
