import 'package:flutter/foundation.dart';
import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';

enum BusinessEventType {
  profileView,
  callClick,
  whatsappClick,
  directionsClick,
  shareClick,
  reviewSubmitted,
}

Future<void> logBusinessEvent(
  String businessId,
  BusinessEventType type, {
  Map<String, dynamic>? metadata,
}) async {
  try {
    await BusinessAnalyticsTable().insert({
      'business_id': businessId,
      'user_id': currentUserUid.isEmpty ? null : currentUserUid,
      'event_type': type.name.toUpperCase(),
      'metadata': metadata ?? {},
    });
  } catch (e) {
    debugPrint('Error logging business event: $e');
  }
}
