// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get home => 'Home';

  @override
  String get search => 'Search';

  @override
  String get services => 'Services';

  @override
  String get cart => 'Cart';

  @override
  String get profile => 'Profile';

  @override
  String get discoveryArea => 'Discovery Area';

  @override
  String get changeLanguage => 'Change Language';

  @override
  String get manageOrders => 'Manage Orders';

  @override
  String get businessDashboard => 'Business Dashboard';

  @override
  String get adminControl => 'Admin Control';

  @override
  String get savedLocations => 'Saved Locations';
}
