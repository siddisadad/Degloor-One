// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Marathi (`mr`).
class AppLocalizationsMr extends AppLocalizations {
  AppLocalizationsMr([String locale = 'mr']) : super(locale);

  @override
  String get home => 'मुख्यपृष्ठ';

  @override
  String get search => 'शोधा';

  @override
  String get services => 'सेवा';

  @override
  String get cart => 'कार्ट';

  @override
  String get profile => 'प्रोफाइल';

  @override
  String get discoveryArea => 'शोध क्षेत्र';

  @override
  String get changeLanguage => 'भाषा बदला';

  @override
  String get manageOrders => 'ऑर्डर व्यवस्थापित करा';

  @override
  String get businessDashboard => 'व्यवसाय डॅशबोर्ड';

  @override
  String get adminControl => 'अ‍ॅडमिन नियंत्रण';

  @override
  String get savedLocations => 'जतन केलेली ठिकाणे';
}
