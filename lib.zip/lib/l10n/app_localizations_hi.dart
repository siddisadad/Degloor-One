// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get home => 'होम';

  @override
  String get search => 'खोजें';

  @override
  String get services => 'सेवाएं';

  @override
  String get cart => 'कार्ट';

  @override
  String get profile => 'प्रोफाइल';

  @override
  String get discoveryArea => 'खोज क्षेत्र';

  @override
  String get changeLanguage => 'भाषा बदलें';

  @override
  String get manageOrders => 'ऑर्डर प्रबंधित करें';

  @override
  String get businessDashboard => 'बिजनेस डैशबोर्ड';

  @override
  String get adminControl => 'एडमिन नियंत्रण';

  @override
  String get savedLocations => 'सहेजे गए स्थान';
}
